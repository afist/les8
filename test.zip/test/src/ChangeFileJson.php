<?php
/**
 * User: Serhii T.
 * Date: 4/25/18
 */

namespace ProcessingFile;

require_once 'DataProcessingInterface/DataProcessing.php';

use ProcessingFile\DataProcessingInterface\DataProcessing;

class ChangeFileJson implements DataProcessing
{
    private $fileWay;

    public function __construct($file_way)
    {
        $this->fileWay = $file_way;
    }

    public function read():array
    {
        return json_decode(file_get_contents($this->fileWay), true);
    }
    public function write(array $arr):void
    {
        file_put_contents($this->fileWay, json_encode($arr, true));
    }
}
