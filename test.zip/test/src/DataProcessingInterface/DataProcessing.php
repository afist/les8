<?php
/**
 * User: Serhii T.
 * Date: 4/25/18
 */
namespace ProcessingFile\DataProcessingInterface;

interface DataProcessing
{
    public function read(): array;
    public function write(array $data): void;
}
