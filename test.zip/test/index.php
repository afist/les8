<?php
/**
 * User: Serhii T.
 * Date: 4/25/18
 */

require_once 'src/ChangeFileJson.php';

use ProcessingFile\ChangeFileJson;

$changeFileJson = new ChangeFileJson('');

echo 'Hi';